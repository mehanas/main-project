﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Admin_Module
{
    public partial class NewConnection : System.Web.UI.Page
    {
        AdminClass aobj = new AdminClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                DataTable dt = new DataTable();

                dt = aobj.showdata();
                if (dt.Rows.Count > 0)
                {
                    gv_connection.DataSource = dt;
                    gv_connection.DataBind();
                }
            
            }
        }

        protected void gv_connection_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow clickedRow = gv_connection.Rows[index];
            HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnConId");
            Session["user_id"] = hidden.Value;
            if (e.CommandName == "Accept")
            {

                 lblmsg.Text = "Accepted";
                
            }

           
        }
    }
}