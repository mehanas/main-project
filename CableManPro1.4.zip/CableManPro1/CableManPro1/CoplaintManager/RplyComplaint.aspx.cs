﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.CoplaintManager
{
    public partial class RplyComplaint : System.Web.UI.Page
    {
        ComplaintClass comobj = new ComplaintClass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["employe"] == null)
            {
                Response.Redirect("~/User/UserHome.aspx");
                Response.Redirect("~/CoplaintManager/ComplaintHome.aspx");
            }
            else if (!IsPostBack)
            {
                DataTable dt = new DataTable();

                dt = comobj.showdata();
                if (dt.Rows.Count > 0)
                {
                    gvcomplaint.DataSource = dt;
                    gvcomplaint.DataBind();
                }
            }

        }

        protected void gvcomplaint_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Reply")
            {
                
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow clickedRow = gvcomplaint.Rows[index];
                HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnComId");
                Session["complaint_id"] = hidden.Value;
                txtrply.Visible = true;
            }
        }

        protected void btnsend_Click(object sender, EventArgs e)
        {
            comobj.Complaint_id =Convert.ToInt32( Session["complaint_id"]);
            comobj.Comp_rply = txtrply.Text;
            comobj.sendcomplaint();
            lblmsg.Text = "send message";
            comobj.Comp_rply = "";
         
           

           
        
            

        }


    }
}