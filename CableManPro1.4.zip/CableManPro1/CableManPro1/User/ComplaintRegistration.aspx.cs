﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class ComplaintRegistration : System.Web.UI.Page
    {

        ComplaintClass comobj = new ComplaintClass();
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsend_Click(object sender, EventArgs e)
        {
            comobj.User_id =Convert.ToInt32(Session["user_id"]);
            comobj.Complaint = txtcomplaint.Text;
           
            comobj.insertcomplaint();
           
        }
    }
}