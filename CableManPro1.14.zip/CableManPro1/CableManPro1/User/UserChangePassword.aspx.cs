﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class UserChangePassword : System.Web.UI.Page
    {
        UserClass uobj = new UserClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["user_id"] == null)
            {
                Response.Redirect("~/User/User Profile.aspx");
            }

            if (!IsPostBack)
            {
                string Uid = Session["user_id"].ToString();

                Loaddata();
            }
        }
         public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            uobj.User_id = Convert.ToInt32(Session["user_id"]);
            dtReg = uobj.disply();
            if (dtReg.Rows.Count > 0)
            {
               txtmail_id.Text = Convert.ToString(dtReg.Rows[0]["user_emailid"]);
                txt_pswd.Text = Convert.ToString(dtReg.Rows[0]["user_password"]);
           
            }
        }

         protected void btn_edit_Click(object sender, EventArgs e)
         {
             // txtmail_id.Enabled = true;
             txt_pswd.Enabled = true;


             btn_edit.Visible = false;
             btn_save.Visible = true;

         }

         protected void btn_save_Click(object sender, EventArgs e)
         {
             uobj.User_id = Convert.ToInt32(Session["user_id"]);
             //uobj.UserEmail = txtmail_id.Text;
             uobj.Upswd = txt_pswd.Text;
             uobj.changepswd();
            
             Response.Write("<script>alert('updation successfully')</script>");
             txt_pswd.Enabled = false;
         }


       
       
    }
}