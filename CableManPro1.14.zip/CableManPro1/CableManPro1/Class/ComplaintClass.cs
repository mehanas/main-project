﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Class
{
    public class ComplaintClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }


        private string complaint;

        public string Complaint
        {
            get { return complaint; }
            set { complaint = value; }
        }

        private int user_id;

        public int User_id
        {
            get { return user_id; }
            set { user_id = value; }
        }



        public int insertcomplaint()
        {

            OpenConection();
            SqlCommand command = new SqlCommand("select max(complaint_id) from complaint", con);
            int complaint_id;
            //  string status;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                complaint_id = (int)cMax;
                complaint_id++;
            }
            else
            {
                complaint_id = 1;
            }
            //status = "not read";
            string qry = "insert into complaint ([complaint_id],[user_id],[complaint_date],[complaint_details] " +
                         ",[complaint_status]) values('" + complaint_id + "',@user_id,GETDATE(),@complaint_details,@status )";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@complaint_details", complaint);
            cmd.Parameters.AddWithValue("@user_id", user_id);

            cmd.ExecuteNonQuery();

            CloseConnection();
            return complaint_id;

        }
        public DataTable showdata()
        {
            OpenConection();
            string qry2 = " select com.complaint_id,com.complaint_date,com.complaint_details,com.complaint_status,usr.user_fname  from " +
                          " complaint com left outer join user_register usr on com.user_id = usr.user_id " +
                          "  and com.complaint_status !='Completed' ";

            SqlCommand cmd = new SqlCommand(qry2, con);


            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;

        }
        private string comp_rply;

        public string Comp_rply
        {
            get { return comp_rply; }
            set { comp_rply = value; }
        }
        private int complaint_id;

        public int Complaint_id
        {
            get { return complaint_id; }
            set { complaint_id = value; }
        }
        public void sendcomplaint()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max( reply_id) from complaint_reply ", con);
            int reply_id;

            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                reply_id = (int)cMax;
                reply_id++;
            }
            else
            {
                reply_id = 1;
            }

            string qry = "insert into complaint_reply ([reply_id],[comp_reply],[reply_date],[complaint_id]) values ('" + reply_id + "',@comp_rply,GETDATE(),@complaint_id)";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@comp_rply", comp_rply);
            cmd.Parameters.AddWithValue("@complaint_id", complaint_id);
            cmd.ExecuteNonQuery();

        }
        private string status;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }


        public void sendstatus()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max(status_id) from complaint_status ", con);
            int status_id;

            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                status_id = (int)cMax;
                status_id++;
            }
            else
            {
                status_id = 1;
            }
            string qry = "insert into complaint_status values ('" + status_id + "',@status,GETDATE(),@comp_id)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@comp_id", complaint_id);
            cmd.ExecuteNonQuery();

        }
        public DataTable currentstatus()
        {
            OpenConection();
            string qry = " select * from dbo.complaint_status where complaint_id =@comp_id order by status_date desc";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@comp_id", complaint_id);
            cmd.ExecuteNonQuery();

            DataTable dtstatus = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtstatus);
            CloseConnection();
            return dtstatus;


        }
        //----------------------------------edit profile--------------------------------------//

        private string e_email;

        public string E_email
        {
            get { return e_email; }
            set { e_email = value; }
        }

        private string e_fname;

        public string E_fname
        {
            get { return e_fname; }
            set { e_fname = value; }
        }

        private string e_mname;

        public string E_mname
        {
            get { return e_mname; }
            set { e_mname = value; }
        }

        private string e_lname;

        public string E_lname
        {
            get { return e_lname; }
            set { e_lname = value; }
        }

        private string e_gender;

        public string E_gender
        {
            get { return e_gender; }
            set { e_gender = value; }
        }

        private string dob;

        public string Dob
        {
            get { return dob; }
            set { dob = value; }
        }
        private string doj;

        public string Doj
        {
            get { return doj; }
            set { doj = value; }
        }

        private string e_housename;

        public string E_housename
        {
            get { return e_housename; }
            set { e_housename = value; }
        }

        private string e_place;

        public string E_place
        {
            get { return e_place; }
            set { e_place = value; }
        }

        private string e_district;

        public string E_district
        {
            get { return e_district; }
            set { e_district = value; }
        }

        private string e_pincode;

        public string E_pincode
        {
            get { return e_pincode; }
            set { e_pincode = value; }
        }

        private string mob;

        public string Mob
        {
            get { return mob; }
            set { mob = value; }
        }
        private string e_qualification;

        public string E_qualification
        {
            get { return e_qualification; }
            set { e_qualification = value; }
        }
        private string e_designation;

        public string E_designation
        {
            get { return e_designation; }
            set { e_designation = value; }
        }

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();

            String qry = "select * from emp_register ";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtReg1 = new DataTable();
            da.Fill(dtReg);

            return dtReg;

        }

        public DataTable disply()
        {
            DataTable dtReg = new DataTable();
            OpenConection();

            String qry = "select * from emp_register where emp_emailid=@e_email";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@e_email", e_email);
            cmd.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);

            CloseConnection();
            return dtReg;



        }
        public void update()
        {

            OpenConection();


            String qry1 = "update emp_register set emp_fname=@e_fname,emp_mname=@e_mname,emp_lname=@e_lname,emp_dob=@emp_dob,emp_doj=@emp_doj,"
            + "emp_housename=@emp_housename,emp_place=@emp_place,emp_district=@emp_district,emp_pincode=@emp_pincode,emp_mob=@emp_mob,"
            + "emp_qualification=@emp_qualification,emp_designation=@emp_designation  where emp_emailid=@e_email ";

            SqlCommand cmd1 = new SqlCommand(qry1, con);

            cmd1.Parameters.AddWithValue("@e_email", e_email);
            cmd1.Parameters.AddWithValue("@e_fname", e_fname);
            cmd1.Parameters.AddWithValue("@e_mname", e_mname);
            cmd1.Parameters.AddWithValue("@e_lname", e_lname);

            cmd1.Parameters.AddWithValue("@emp_dob", dob);
            cmd1.Parameters.AddWithValue("@emp_doj", doj);
            cmd1.Parameters.AddWithValue("@emp_housename", e_housename);

            cmd1.Parameters.AddWithValue("@emp_place", e_place);
            cmd1.Parameters.AddWithValue("@emp_district", e_district);
            cmd1.Parameters.AddWithValue("@emp_pincode", e_pincode);

            cmd1.Parameters.AddWithValue("@emp_mob", mob);
            cmd1.Parameters.AddWithValue("@emp_qualification", e_qualification);
            cmd1.Parameters.AddWithValue("@emp_designation", e_designation);

            cmd1.ExecuteNonQuery();




        }




    }   

}