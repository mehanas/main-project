﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.PackageManager
{
    public partial class AddPackages : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();

        protected void Page_Load(object sender, EventArgs e)
        {
            Load_Package_Data();
        }
        private void Load_Package_Data()
        {
            DataTable dtpackage= new DataTable();
            dtpackage = pobj.show_package_data();

            if (dtpackage.Rows.Count > 0)
            {
                gvpackage.DataSource =dtpackage ;
                gvpackage.DataBind();
            }


        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            pobj.Package_name = txtpack_name.Text;
            pobj.Package_rate = Convert.ToInt32(txtpack_rate.Text);
            pobj.No_of_channels=txt_no_channels.Text;
   
            pobj.insertpackage();

            lblmsg.Text = "Channel Inserted";

        }


        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/PackageManager/AddPackages.aspx");
        }

       

    }
}