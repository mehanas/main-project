﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.PackageManager
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["packageemploy"] == null)
            {
                Response.Redirect("~/PackageManager/PackageHome.aspx");
            }

            if (!IsPostBack)
            {
                string Uid = Session["packageemploy"].ToString();

                Loaddata();
            }
        }
        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            pobj.E_email = Session["packageemploy"].ToString();
            dtReg = pobj.disply();
            if (dtReg.Rows.Count > 0)
            {
                txtmail_id.Text = Convert.ToString(dtReg.Rows[0]["emp_emailid"]);
                txt_pswd.Text = Convert.ToString(dtReg.Rows[0]["emp_password"]);
            }
        }

        protected void btn_edit_Click(object sender, EventArgs e)
        {
            txt_pswd.Enabled = true;
            btn_edit.Visible = false;
            btn_save.Visible = true;

        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            pobj.E_email = Session["packageemploy"].ToString();
            //uobj.UserEmail = txtmail_id.Text;
           // pobj.emp_password = txt_pswd.Text;
            pobj.changepswd();

            Response.Write("<script>alert('updation successfully')</script>");
            txt_pswd.Enabled = false;
        }
    }
}