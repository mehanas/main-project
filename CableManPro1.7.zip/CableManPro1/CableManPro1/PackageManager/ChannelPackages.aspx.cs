﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;


namespace CableManPro1.PackageManager
{
    public partial class ChannelPackages : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadData();
                Load_Package_Data();
            }
        }
        private void LoadData()
        {
            DataTable dtchannel = new DataTable();
            dtchannel = pobj.show_channel_data();

            if (dtchannel.Rows.Count > 0)
            {
               gvch_select.DataSource = dtchannel;
                gvch_select.DataBind();
             

                
            }


        }
        private void Load_Package_Data()
        {
            DataTable dtpackage = new DataTable();
            dtpackage = pobj.show_package_data();

            if (dtpackage.Rows.Count > 0)
            {
              //  gvpkg_select.DataSource = dtpackage;
             //   gvpkg_select.DataBind();

                gvPackage.DataSource = dtpackage;
                gvPackage.DataBind();
            }


        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gvPackage.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    //refrence control inside grid view
                    RadioButtonList radioList = (RadioButtonList)row.FindControl("rblChoose");
                    string questionID = row.Cells[0].Text;
                }
            }
        }

        protected void gvpkg_select_RowCommand(object sender, GridViewCommandEventArgs e)
        {
          /*  int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow clickedRow = gvpkg_select.Rows[index];
            HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnPackId");*/
        }

        protected void gvPackage_RowCommand(object sender, GridViewCommandEventArgs e)
        {
              int index = Convert.ToInt32(e.CommandArgument);
              GridViewRow clickedRow = gvPackage.Rows[index];
              HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnPackageId");
              string packageId = hidden.Value;


        }

     
        

       


    }
}