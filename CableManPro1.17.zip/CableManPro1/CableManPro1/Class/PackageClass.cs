﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace CableManPro1.Class
{
    public class PackageClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// -------------------insert channel----------------
        /// </summary>


        private string channel;
        private int channelId;

        public int ChannelId
        {
            get { return channelId; }
            set { channelId = value; }
        }
        private int packageId;

        public int PackageId
        {
            get { return packageId; }
            set { packageId = value; }
        }
             

        public string Channel
        {
            get { return channel; }
            set { channel = value; }
        }
        private string language;

        public string Language
        {
            get { return language; }
            set { language = value; }
        }
        private Int32 channel_rate;

        public Int32 Channel_rate
        {
            get { return channel_rate; }
            set { channel_rate = value; }
        }


        public void insertchannel()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max (channel_id) from channel_details  ", con);
            int channel_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                channel_id = (int)cMax;
                channel_id++;
            }
            else
            {
                channel_id = 1;
            }
            string qry = "insert into channel_details values('" + channel_id + "',@channel,@language,@channel_rate)";
            SqlCommand cmd = new SqlCommand(qry, con);
            //cmd.Parameters.AddWithValue("@channel_id", channel_id);
            cmd.Parameters.AddWithValue("@channel", channel);
            cmd.Parameters.AddWithValue("@language", language);
            cmd.Parameters.AddWithValue("@channel_rate", channel_rate);
            cmd.ExecuteNonQuery();

        }
        public DataTable show_channel_data()
        {

            OpenConection();
            string qry2 = " select * from channel_details";

            SqlCommand cmd = new SqlCommand(qry2, con);


            cmd.ExecuteNonQuery();

            DataTable dtchannel = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtchannel);
            CloseConnection();
            return dtchannel;


        }


        
        ///---------------insert package---------------------

       
        private string package_name;

        public string Package_name
        {
            get { return package_name; }
            set { package_name = value; }
        }

        private Int32 package_rate;

        public Int32 Package_rate
        {
            get { return package_rate; }
            set { package_rate = value; }
        }

        

        private string no_of_channels;

        public string No_of_channels
        {
            get { return no_of_channels; }
            set { no_of_channels = value; }
        }
       

      
        public void insertpackage()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max (package_id) from package_details  ", con);
            int package_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                package_id = (int)cMax;
                package_id++;
            }
            else
            {
                package_id = 1;
            }
            string qry = "insert into package_details values('" + package_id + "',@package_name,@package_rate,@no_of_channels)";
            SqlCommand cmd = new SqlCommand(qry, con);
            //cmd.Parameters.AddWithValue("@broadcaster", broadcaster);
            cmd.Parameters.AddWithValue("@package_name", package_name);
            cmd.Parameters.AddWithValue("@package_rate", package_rate);
            cmd.Parameters.AddWithValue("@no_of_channels",no_of_channels);
           // cmd.Parameters.AddWithValue("@channel_id", channel_id);
            cmd.ExecuteNonQuery();
        }

        public DataTable show_package_data()
        {

            OpenConection();
            string qry2 = " select * from package_details";

            SqlCommand cmd = new SqlCommand(qry2, con);


            cmd.ExecuteNonQuery();

            DataTable dtpackage = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtpackage);
            CloseConnection();
            return dtpackage;


        }

        public DataTable BindBroadcaster()
        {

            OpenConection();
            string qry2 = " select * from broadcaster ";

            SqlCommand cmd = new SqlCommand(qry2, con);


            cmd.ExecuteNonQuery();

            DataTable dtBrd= new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtBrd);
            CloseConnection();
            return dtBrd;


        }

        public DataTable Retrievepackage_data()
        {

            OpenConection();
            string qry2 = "   Select "+
                          "   pd.package_id,  pd.package_name, pd.package_cost, pd.no_of_channels "+
                          "   from broadcaster b "+
                          "  left outer join package_broadcaster pb on b.broadcaster_id = pb.broadcaster_id "+
                          "  left outer join package_details pd on pb.package_id = pd.package_id "+
                          "  where b.broadcaster_id=@broadcaster_id ";

            SqlCommand cmd = new SqlCommand(qry2, con);

            cmd.Parameters.AddWithValue("@broadcaster_id", broadcaster_id);
            cmd.ExecuteNonQuery();

            DataTable dtpackage = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtpackage);
            CloseConnection();
            return dtpackage;
            
        }

//---------channel package------------------



        public void InsertChannelPackage()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max (ch_pkg_id) from channelpackage ", con);
            int ch_pkg_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                ch_pkg_id = (int)cMax;
                ch_pkg_id++;
            }
            else
            {
                ch_pkg_id = 1;
            }
            string qry = "insert into channelpackage values('" + ch_pkg_id + "',@packageId,@channelId)";
            SqlCommand cmd = new SqlCommand(qry, con); 
            cmd.Parameters.AddWithValue("@packageId", packageId);
            cmd.Parameters.AddWithValue("@channelId", channelId);
          
            cmd.ExecuteNonQuery();

        }
        public DataTable selectchannel()
        {
            OpenConection();
            string qry2 = " select * from channel_details where channel_id in(select channel_id from channelpackage where package_id=@packageId)";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@packageId", packageId);
            cmd.Parameters.AddWithValue("@channel_id", channelId);


            cmd.ExecuteNonQuery();

            DataTable dtchannel = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtchannel);
            CloseConnection();
            return dtchannel;


        }

//-------------------view channel package-------------------------//

        private string employ_emailid;

        public string Employ_emailid
        {
            get { return employ_emailid; }
            set { employ_emailid = value; }
        }

        public DataTable showdata()
        {
            OpenConection();
            string qry2 = "select * from emp_register  where emp_emailid=@emailid";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@emailid",employ_emailid);

            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;




        }



 //----------------------------edit profile----------------------------

        private string e_email;

        public string E_email
        {
            get { return e_email; }
            set { e_email = value; }
        }

        private string e_fname;

        public string E_fname
       {
        get { return e_fname; }
        set { e_fname = value; }
       }

      private string e_mname;

      public string E_mname
      {
          get { return e_mname; }
          set { e_mname = value; }
      }

      private string e_lname;

      public string E_lname
      {
          get { return e_lname; }
          set { e_lname = value; }
      }
      private string e_gender;

      public string E_gender
      {
          get { return e_gender; }
          set { e_gender = value; }
      }
      private string dob;

      public string Dob
      {
          get { return dob; }
          set { dob = value; }
      }
      private string doj;

      public string Doj
      {
          get { return doj; }
          set { doj = value; }
      }
      private string e_housename;

      public string E_housename
      {
          get { return e_housename; }
          set { e_housename = value; }
      }
      private string e_place;

      public string E_place
      {
          get { return e_place; }
          set { e_place = value; }
      }
      private string e_district;

      public string E_district
      {
          get { return e_district; }
          set { e_district = value; }
      }

      private string e_pincode;

      public string E_pincode
      {
          get { return e_pincode; }
          set { e_pincode = value; }
      }

      private string mob;

      public string Mob
      {
          get { return mob; }
          set { mob = value; }
      }

      private string e_qualification;

      public string E_qualification
      {
          get { return e_qualification; }
          set { e_qualification = value; }
      }

      private string e_designation;

      public string E_designation
      {
          get { return e_designation; }
          set { e_designation = value; }
      }

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();

            String qry = "select * from emp_register ";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtReg1 = new DataTable();
            da.Fill(dtReg);
          
            return dtReg;

        }

        public DataTable disply()
        {
            DataTable dtReg = new DataTable();
            OpenConection();

            String qry = "select * from emp_register where emp_emailid=@e_email";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@e_email", e_email);
            cmd.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);

            CloseConnection();
            return dtReg;

        }

        public void update()
        {
           
            OpenConection();


            String qry1 = "update emp_register set emp_fname=@e_fname,emp_mname=@e_mname,emp_lname=@e_lname,emp_dob=@emp_dob,emp_doj=@emp_doj,"
            +"emp_housename=@emp_housename,emp_place=@emp_place,emp_district=@emp_district,emp_pincode=@emp_pincode,emp_mob=@emp_mob,"
            + "emp_qualification=@emp_qualification,emp_designation=@emp_designation where emp_emailid=@e_email ";

            SqlCommand cmd1 = new SqlCommand(qry1, con);

           
            cmd1.Parameters.AddWithValue("@e_fname", e_fname);
            cmd1.Parameters.AddWithValue("@e_mname", e_mname);
            cmd1.Parameters.AddWithValue("@e_lname", e_lname);

            cmd1.Parameters.AddWithValue("@emp_dob",dob);
            cmd1.Parameters.AddWithValue("@emp_doj", doj);
            cmd1.Parameters.AddWithValue("@emp_housename", e_housename);

            cmd1.Parameters.AddWithValue("@emp_place", e_place);
            cmd1.Parameters.AddWithValue("@emp_district",e_district);
            cmd1.Parameters.AddWithValue("@emp_pincode", e_pincode);

            cmd1.Parameters.AddWithValue("@emp_mob",mob);
            cmd1.Parameters.AddWithValue("@emp_qualification", e_qualification);
            cmd1.Parameters.AddWithValue("@emp_designation", e_designation);
            cmd1.Parameters.AddWithValue("@e_email", e_email);
            
            cmd1.ExecuteNonQuery();


        }
        private int emp_id;

        public int Emp_id
        {
            get { return emp_id; }
            set { emp_id = value; }
        }
        private string emp_password;

        public string Emp_password
        {
            get { return emp_password; }
            set { emp_password = value; }
        }
        public void changepswd()
        {
            OpenConection();
            String qry1 = "update  emp_register set emp_password=@emp_password where emp_emailid=@e_email ";

            SqlCommand cmd1 = new SqlCommand(qry1, con);
            cmd1.Parameters.AddWithValue("@e_email", e_email);
            cmd1.Parameters.AddWithValue("@emp_password", emp_password);
            cmd1.ExecuteNonQuery();

        }

//================add Broadcaster========================

        private string broadcaster;

        public string Broadcaster
        {
            get { return broadcaster; }
            set { broadcaster = value; }
        }
        public void insertbroadcaster()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max (broadcaster_id) from broadcaster  ", con);
            int broadcaster_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                broadcaster_id = (int)cMax;
                broadcaster_id++;
            }
            else
            {
                broadcaster_id = 1;
            }
            string qry = "insert into broadcaster values('" + broadcaster_id + "',@broadcaster)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@broadcaster", broadcaster);
                      
            cmd.ExecuteNonQuery();
        }

        //======================packagebroadcaster==============

        private int broadcaster_id;

        public int Broadcaster_id
        {
            get { return broadcaster_id; }
            set { broadcaster_id = value; }
        }

        public void InsertPackageBroadcaster()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max (pac_broadcast_id) from package_broadcaster ", con);
            int pac_broadcast_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                pac_broadcast_id = (int)cMax;
                pac_broadcast_id++;
            }
            else
            {
                pac_broadcast_id = 1;
            }
            string qry = "insert into channelpackage values('" + pac_broadcast_id + "',@Broadcaster_id,@packageId)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@Broadcaster_id", Broadcaster_id);
            cmd.Parameters.AddWithValue("@packageId", packageId);
           

            cmd.ExecuteNonQuery();

        }

    }
}
