﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Class
{
    public class AdminClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        
        //---------------Connection Request-----------------------------------

        private int user_id;

        public int User_id
        {
            get { return user_id; }
            set { user_id = value; }
        }

        private string con_date;

        public string Con_date
        {
            get { return con_date; }
            set { con_date = value; }
        }

        private string con_status;

        public string Con_status
        {
            get { return con_status; }
            set { con_status = value; }
        }
        private string net_status;

        public string Net_status
        {
            get { return net_status; }
            set { net_status = value; }
        }

        public int SendRequest()
        {

            OpenConection();
            SqlCommand command = new SqlCommand("select max(con_id) from connection", con);
            int con_id;
            //string con_status;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                con_id = (int)cMax;
                con_id++;
            }
            else
            {
                con_id = 1;
            }
            // con_status = "not accepted";
            string qry = "insert into connection values('" + con_id + "',@user_id,GETDATE(),@con_status,@net_status )";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@user_id", user_id);
            cmd.Parameters.AddWithValue("@con_status", con_status);
            cmd.Parameters.AddWithValue("@net_status", net_status);

            cmd.ExecuteNonQuery();

            CloseConnection();
            return con_id;

        }





        //-------------Activate new connection---------------



        public DataTable showdata()
        {
            OpenConection();
            //string qry2 = " select con.con_id,con.con_date,con.con_status,con.net_status,usr.user_fname  from " +
            //              " connection con left outer join user_register usr on con.user_id = usr.user_id " +
            //              "  and con.con_status ='Not Accepted'";

            string qry2 = "select con_id,con_date,user_fname,case when net_status = 1 then 'yes' "+
                          "when net_status = 0 then 'no' end as net_status  from connection join user_register on"+
                          " connection .user_id = user_register.user_id where con_status=0 ";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.ExecuteNonQuery();
            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;

        }

        public void acceptdata()
        {
            OpenConection();
            string qry = " UPDATE connection SET con_status= '1' WHERE con_id =@con_id";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@con_id", user_id);
            int numberOfRecords = cmd.ExecuteNonQuery();
            //DataTable dtAccReg = new DataTable();
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //da.Fill(dtAccReg);
            //CloseConnection();
            //return dtAccReg;
        
        }

        //-------------------view All connection---------------------


        public DataTable viewconnection()
        {
            OpenConection();
                    

            string qry2 = "select con_id,con_date,user_fname,user_lname,case when net_status = 1 then 'yes' "+
                          "when net_status = 0 then 'no' end as net_status  from connection join user_register on"+
                          " connection .user_id = user_register.user_id where con_status!=0 ";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.ExecuteNonQuery();
            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;


        }

        //=====================already exist connection===============

        
        public DataTable alreadyconnection()
        {

            OpenConection();
            string qry1 = "select * from connection where user_id=@user_id";
            SqlCommand cmd = new SqlCommand(qry1, con);
            cmd.Parameters.AddWithValue("@user_id", user_id);
            cmd.ExecuteNonQuery();
            DataTable dtcon = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtcon);
            CloseConnection();
            return dtcon;

        
        }
        //=============disconnection==========================


        public DataTable disconnection()
        {
            OpenConection();
            String qry1 = "delete from connection where user_id=@user_id";
            SqlCommand cmd1 = new SqlCommand(qry1, con);
            cmd1.Parameters.AddWithValue("@user_id", user_id);

            cmd1.ExecuteNonQuery();
            DataTable dtcon = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            da.Fill(dtcon);
            CloseConnection();
            return dtcon;

        }

        






    }
}


    
