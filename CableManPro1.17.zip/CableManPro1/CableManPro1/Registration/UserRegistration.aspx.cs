﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;

namespace CableManPro1.Registration
{
    public partial class UserRegistration : System.Web.UI.Page
    {

        
        CableClass cobj = new CableClass();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmessage.Visible = false;
        }

        protected void Btnregister_Click1(object sender, EventArgs e)
        {
            cobj.Uemail = txtuemailid.Text;
            string utyp = "";
            utyp = cobj.userdata();
            if (utyp != null)
            {

                Response.Write("<script>alert('username already exists')</script>");
            }
            else
            {

                if (rdbufemale.Checked)
                {
                    cobj.Ugender = rdbufemale.Text;
                }
                else
                {
                    cobj.Ugender = rdbumale.Text;
                }

                cobj.Ufname = txtufname.Text;
                cobj.Umname = txtumname.Text;
                cobj.Ulname = txtulname.Text;
                cobj.Uhousename = txtuhousename.Text;
                cobj.Uwardnum = Convert.ToInt16(txtwardnum.Text);
                cobj.Uplace = txtuplace.Text;
                cobj.Umob = Convert.ToInt64(txtuphn.Text);
                cobj.Uemail = txtuemailid.Text;
                cobj.Upassword = txtupassword.Text;

                cobj.UserRegistration();

                Response.Write("<script>alert('Registration successfully')</script>");

                string msg = "Thanks for choosing this website.You are succesfully Registered!!!Login to complete your profile.";
                using (StringWriter sw = new StringWriter())
                {
                    using (HtmlTextWriter ht = new HtmlTextWriter(sw))
                    {
                        StringReader sr = new StringReader(sw.ToString());
                        MailMessage mail = new MailMessage();
                        mail.From = new MailAddress("grouptravelix2018@gmail.com");
                        mail.To.Add(txtuemailid.Text.ToString());
                        mail.Subject = "Cable registration";
                        // string body = LblMsg.Text.ToString();
                        mail.Body = msg;
                        mail.IsBodyHtml = true;
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = "smtp.gmail.com";
                        System.Net.NetworkCredential nt = new NetworkCredential();
                        nt.UserName = "grouptravelix2018@gmail.com";
                        nt.Password = "travelix1234";
                        smtp.UseDefaultCredentials = true;
                        smtp.Credentials = nt;
                        smtp.Port = 587;
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                }

                lblmessage.Visible = true;

                txtuemailid.Text = "";
                txtufname.Text = "";
                txtumname.Text = "";
                txtulname.Text = "";
                txtuhousename.Text = "";
                txtwardnum.Text = "";
                txtuplace.Text = "";
                txtuphn.Text = "";
                txtupassword.Text = "";
                

           
            }
            
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Registration/UserRegistration.aspx");
        }
        
    }
}