﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.PackageManager
{
    public partial class PackageBroadcaster : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadBroadCaster();

                
            }
        }

          private void Load_Package_Data()
          {
            DataTable dtpackage = new DataTable();
            pobj.Broadcaster_id = Convert.ToInt32(dd_broadcaster.SelectedValue);
            dtpackage = pobj.Retrievepackage_data();

            if (dtpackage.Rows.Count > 0)
            {
                gvPackage.DataSource = dtpackage;
                gvPackage.DataBind();
            }


        }

          private void LoadBroadCaster()
          {
              DataTable dtBrd = new DataTable();
              dtBrd = pobj.BindBroadcaster();
              if (dtBrd.Rows.Count > 0)
              {
                  dd_broadcaster.DataSource = dtBrd;
                  dd_broadcaster.DataTextField = "broadcaster";
                  dd_broadcaster.DataValueField = "broadcaster_id";
                  dd_broadcaster.DataBind();
                  Load_Package_Data();
              }
          }

        
          protected void dd_broadcaster_SelectedIndexChanged(object sender, EventArgs e)
          {
            
              Load_Package_Data();
          }

         
         
        

        

       
    }
}