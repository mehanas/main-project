﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Admin_Module
{
    public partial class ViewAllComplaint : System.Web.UI.Page
    {
        ComplaintClass comobj = new ComplaintClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            rbn_status.Visible = false;

            if (!IsPostBack)
            {
                DataTable dt = new DataTable();

                dt = comobj.showdata();
                if (dt.Rows.Count > 0)
                {
                    gv_complaint.DataSource = dt;
                    gv_complaint.DataBind();
                }
            }

        }

        protected void gv_complaint_RowCommand(object sender, GridViewCommandEventArgs e)
        {

            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow clickedRow = gv_complaint.Rows[index];
            HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnComId");
            Session["complaint_id"] = hidden.Value;
         
            if (e.CommandName == "Reply")
            {


                
                ViewState["action"] = "Reply";
            }
            else if (e.CommandName == "View Status")
            {
                DataTable dtstatus = new DataTable();
                comobj.Complaint_id = Convert.ToInt32(Session["complaint_id"]);
                dtstatus = comobj.currentstatus();
                if (dtstatus.Rows.Count > 0)
                {
                    rbn_status.SelectedValue = Convert.ToString(dtstatus.Rows[0]["Status"]);
                }

                rbn_status.Visible = true;
                ViewState["action"] = "View Status";
            }
        }
    }
}