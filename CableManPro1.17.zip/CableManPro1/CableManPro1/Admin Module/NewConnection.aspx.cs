﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Admin_Module
{
    public partial class NewConnection : System.Web.UI.Page
    {
        AdminClass aobj = new AdminClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                DataTable dt = new DataTable();
                DataTable dtAccReg = new DataTable();

                dt= aobj.showdata();
                if (dt.Rows.Count > 0)
                {
                    gv_connection.DataSource = dt;
                    gv_connection.DataBind();
                }
            
            }
        }

        protected void gv_connection_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow clickedRow = gv_connection.Rows[index];
            HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnConId");
    
            if (e.CommandName == "Approve")
            {
                 aobj.User_id = Convert.ToInt32(hidden.Value);
                 aobj.acceptdata();
                 lblmsg.Text = "Approved";
               
            }

           
        }
    }
}