﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Admin_Module
{
    public partial class EmployeRegistration : System.Web.UI.Page
    {


        CableClass cobj = new CableClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            

            if (rdbefemale.Checked)
            {
                cobj.Egender = rdbefemale.Text;
            }
            else
            {
                cobj.Egender = rdbemale.Text;
            }

            cobj.Efname = txtefname.Text;
            cobj.Emname = txtemname.Text;
            cobj.Elname = txtelname.Text;
            cobj.Edob =txtedob.Text  ;
            cobj.Edoj = txtedoj.Text;
            cobj.Ehousename = txtehousename.Text;
            cobj.Eplace = txteplace.Text;
            cobj.Edistrict = txtedistrict.Text;
            cobj.Epincode = txtepincode.Text;
            cobj.Emob = txtephoneno.Text;
            cobj.Equalification = txtequalification.Text;
            if (Convert.ToInt32(dpdedesignation.SelectedValue)!=0)
            cobj.Edesignation = dpdedesignation.SelectedItem.Text;
            cobj.Eemail = txteemailid.Text;
            cobj.Epassword = txtepassword.Text;

            cobj.EmployeRegistration();

            lblmsg.Visible = true;
            Response.Write("<script>alert('Registration successfully')</script>");
          //  lblmsg.Text = " Registration Sucessfully"; 
                


        }

        protected void btncancel_Click(object sender, EventArgs e)
        {



            txteemailid.Text = "";
            txtefname.Text = "";
            txtemname.Text = "";
            txtelname.Text = "";
            txtedob.Text = "";
            txtedoj.Text = "";
            txtehousename.Text = "";
            txteplace.Text = "";
            txtedistrict.Text = "";
            txtepincode.Text = "";
            txtephoneno.Text = "";
            txtequalification.Text = "";
            dpdedesignation.Text = "";
            txteemailid.Text = "";
            txtepassword.Text = "";
        }
    }
}