﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class Bill : System.Web.UI.Page
    {
        UserClass uobj = new UserClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string Uid = Session["user_id"].ToString();

                payment();
            }
        }

        public void payment()
        {
            DataTable dtReg = new DataTable();
            uobj.User_id = Convert.ToInt32(Session["user_id"]);
            dtReg = uobj.displayuser();
            if (dtReg.Rows.Count > 0)
            {

                txt_user_id.Text = Convert.ToString(dtReg.Rows[0]["user_id"]);
                txt_user.Text = Convert.ToString(dtReg.Rows[0]["user_fname"]) +" " + Convert.ToString(dtReg.Rows[0]["user_lname"]);
             
                txt_address.Text = Convert.ToString(dtReg.Rows[0]["user_housename"]); 
                txt_wardno.Text = Convert.ToString(dtReg.Rows[0]["user_wardno"]);
                txt_place.Text = Convert.ToString(dtReg.Rows[0]["user_place"]);


                txt_phone.Text = Convert.ToString(dtReg.Rows[0]["user_mob"]);
                txt_email.Text = Convert.ToString(dtReg.Rows[0]["user_emailid"]);



                //txt_package_amt.Text = Convert.ToString(dtReg.Rows[0]["package_cost"]);
                //txt_internet_amt.Text = "100";


            }

        }
    }
}