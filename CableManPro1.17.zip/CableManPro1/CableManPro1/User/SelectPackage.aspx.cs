﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class SelectPackage : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["user_id"] == null)
            {
                Response.Redirect("~/User/User Profile.aspx");
            }

            gv_channel.Visible = false;

            if (!IsPostBack)
            {
                LoadBroadCaster();
                //Load_Package_Data();
              // selectchannel();

            }
        }
       
        private void Load_Package_Data()
        {
            DataTable dtpackage = new DataTable();
            pobj.Broadcaster_id = Convert.ToInt32(dd_broadcaster.SelectedValue);
            dtpackage = pobj.Retrievepackage_data();

            if (dtpackage.Rows.Count > 0)
            {
               gv_package.DataSource = dtpackage;
               gv_package.DataBind();
            }


        }
        private void LoadBroadCaster()
        {
            DataTable dtBrd = new DataTable();
            dtBrd = pobj.BindBroadcaster();
            if (dtBrd.Rows.Count > 0)
            {
                dd_broadcaster.DataSource = dtBrd;
                dd_broadcaster.DataTextField = "broadcaster";
                dd_broadcaster.DataValueField = "broadcaster_id";
                dd_broadcaster.DataBind();
                Load_Package_Data();
            }
        }
        //private void Load_Package_Data()
        //{
        //    DataTable dtpackage = new DataTable();
        //    dtpackage = pobj.show_package_data();

        //    if (dtpackage.Rows.Count > 0)
        //    {

        //        gv_package.DataSource = dtpackage;
        //        gv_package.DataBind();
        //    }
        //}
        private void selectchannel()
        {

            DataTable dtchannel = new DataTable();
            pobj.PackageId = Convert.ToInt32(ViewState["PackageId"]);
            dtchannel = pobj.selectchannel();

            if (dtchannel.Rows.Count > 0)
            {

                gv_channel.DataSource = dtchannel;
                gv_channel.DataBind();
                gv_channel.Visible = true;
            }

        }

        protected void gv_package_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //if(ddpbradcaster.)
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow clickedRow = gv_package.Rows[index];

            HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnPackageId");

            ViewState["PackageId"] = gv_package.Rows[index].Cells[0].Text;
            lblmsg.Text = "Package : " + clickedRow.Cells[1].Text;
            selectchannel();
        }

        protected void btn_payment_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/User/Bill.aspx");
        }

        protected void dd_broadcaster_SelectedIndexChanged(object sender, EventArgs e)
        {
            Load_Package_Data();
        }

        protected void btn_payment_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/User/Bill.aspx");
        }

      

       
    }
}