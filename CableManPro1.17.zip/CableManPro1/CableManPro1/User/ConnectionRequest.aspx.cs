﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class ConnectionRequest : System.Web.UI.Page
    {
        AdminClass aobj = new AdminClass();

        protected void Page_Load(object sender, EventArgs e)
        {

            
            aobj.User_id=Convert.ToInt32(Session["user_id"]);

            DataTable dtconnection = new DataTable();
            dtconnection = aobj.alreadyconnection();
            if (dtconnection.Rows.Count > 0)
            {
                divConReq.Visible = false;
                divNoCon.Visible = true;
                btn_disconnect.Visible = true;
                
               
            }
            else
            {
                divConReq.Visible = true;
                divNoCon.Visible = false;
                btn_disconnect.Visible = false;
            }



            //if (dtconnection == Session["user_id"])
            //{

            //    Response.Write("<script>alert('username already exists')</script>");
            //}
            
        }
       
        
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
             lblmsg.Visible = true;
            
             aobj.User_id = Convert.ToInt32(Session["user_id"]); 
             aobj.Con_status = "0";

             

             if (chk_internet.Checked== true)
             {
                 aobj.Net_status = "1";
             }
             else 
             {

                 aobj.Net_status = "0";
             }


            

             aobj.SendRequest();

             Response.Redirect("~/User/SelectPackage.aspx");
 
             //if (aobj.Con_status == "1")
             //{

             //    Response.Redirect("~/User/SelectPackage.aspx");
 
             
             //}

             lblmsg.Text = "Request send";
            
         
        }

        protected void btn_disconnect_Click(object sender, EventArgs e)
        {

            aobj.User_id = Convert.ToInt32(Session["user_id"]);
            DataTable dt_disconnection = new DataTable();
            dt_disconnection = aobj.disconnection();
            Response.Write("<script>alert('you are discconected')</script>");

        }

     
       


    }
}