﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.CoplaintManager
{
    public partial class ViewComplaintMngrProfile : System.Web.UI.Page
    {
        ComplaintClass cobj = new ComplaintClass();

        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;

            if (HttpContext.Current.Session["employe"] == null)
            {
                Response.Redirect("~/CoplaintManager/ViewMyProfile.aspx");
            }

            if (!IsPostBack)
            {
                string Uid = Session["employe"].ToString();

                Loaddata();
            }
         }

         public void Loaddata()
         {
            DataTable dtReg = new DataTable();
            cobj.E_email = Session["employe"].ToString();
            dtReg = cobj.disply();
            if (dtReg.Rows.Count > 0)
            {
               
                    if (dtReg.Rows[0]["emp_gender"].ToString() == "male")
                    {
                        rdbmale.Checked = true;

                    }
                    else
                    {
                        rdbfemale.Checked = true;
                    }

                txtfname.Text = Convert.ToString(dtReg.Rows[0]["emp_fname"]);
                txtmname.Text = Convert.ToString(dtReg.Rows[0]["emp_mname"]);
                txtlname.Text = Convert.ToString(dtReg.Rows[0]["emp_lname"]);
                txtdob.Text=Convert.ToString(dtReg.Rows[0]["emp_dob"]);
                txtdoj.Text = Convert.ToString(dtReg.Rows[0]["emp_doj"]);
                txthousename.Text = Convert.ToString(dtReg.Rows[0]["emp_housename"]);
                txtplace.Text = Convert.ToString(dtReg.Rows[0]["emp_place"]);
                txtdistrict.Text = Convert.ToString(dtReg.Rows[0]["emp_district"]);
                txtpincode.Text=Convert.ToString(dtReg.Rows[0]["emp_pincode"]);
                txtmob.Text = Convert.ToString(dtReg.Rows[0]["emp_mob"]);
                txtqualification.Text = Convert.ToString(dtReg.Rows[0]["emp_qualification"]);
                txtdesignation.Text = Convert.ToString(dtReg.Rows[0]["emp_designation"]);
                txtemail.Text = Convert.ToString(dtReg.Rows[0]["emp_emailid"]);
               
               
            }
        }


        

        protected void btnedit_Click(object sender, EventArgs e)
        {
            txtfname.Enabled = true;
            txtmname.Enabled = true;
            txtlname.Enabled = true;
           //txtdoj.Enabled = true;
            txtdob.Enabled = true;
            txtdistrict.Enabled = true;
            txthousename.Enabled = true;
            txtplace.Enabled = true;
            txtpincode.Enabled = true;
            txtmob.Enabled = true;
            txtqualification.Enabled = true;
             //txtemail.Enabled = true;
            btnupdate.Visible = true;
            btnedit.Visible = false;
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            cobj.E_email = Session["employe"].ToString(); 
            cobj.E_fname = txtfname.Text;
            cobj.E_mname = txtmname.Text;
            cobj.E_lname = txtlname.Text;
            cobj.Dob = txtdob.Text;
            cobj.Doj = txtdoj.Text;
            cobj.E_housename = txthousename.Text;
            cobj.E_place = txtplace.Text;
            cobj.E_district = txtdistrict.Text;
            cobj.E_pincode = txtpincode.Text;
            cobj.Mob = txtmob.Text;
            cobj.E_qualification = txtqualification.Text;
            cobj.E_designation = txtdesignation.Text;
            cobj.update();
            lblmsg.Visible = true;
            lblmsg.Text = "data updated";
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/CoplaintManager/ViewMyProfile.aspx");
        }

        


    }
}