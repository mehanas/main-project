﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class User_Profile : System.Web.UI.Page
    {
        UserClass uobj = new UserClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["user_id"] == null)
            {
                Response.Redirect("~/User/User Profile.aspx");
            }

            if (!IsPostBack)
            {
                string Uid = Session["user_id"].ToString();

                Loaddata();
            }
        }


        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            uobj.User_id =  Convert.ToInt32(Session["user_id"]);
            dtReg = uobj.disply();
            if (dtReg.Rows.Count > 0)
            {

                if (dtReg.Rows[0]["user_gender"].ToString() == "male")
                {
                    rdbmale.Checked = true;

                }
                else
                {
                    rdbfemale.Checked = true;
                }

                txtfname.Text = Convert.ToString(dtReg.Rows[0]["user_fname"]);
                txtmname.Text = Convert.ToString(dtReg.Rows[0]["user_mname"]);
                txtlname.Text = Convert.ToString(dtReg.Rows[0]["user_lname"]);
        
                txthousename.Text = Convert.ToString(dtReg.Rows[0]["user_housename"]);
                txtwardno.Text = Convert.ToString(dtReg.Rows[0]["user_wardno"]);
                txtplace.Text = Convert.ToString(dtReg.Rows[0]["user_place"]);
             
              
                txtphoneno.Text = Convert.ToString(dtReg.Rows[0]["user_mob"]);
                txtemail.Text = Convert.ToString(dtReg.Rows[0]["user_emailid"]);


            }
        }


        protected void btnedit_Click(object sender, EventArgs e)
        {

            txtfname.Enabled = true;
            txtmname.Enabled = true;
            txtlname.Enabled = true;
     
           
            txthousename.Enabled = true;
            txtwardno.Enabled = true;
            txtplace.Enabled = true;

            txtwardno.Enabled = true;
            txtphoneno.Enabled = true;

         
            btnupdate.Visible = true;
            btnedit.Visible = false;
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/User/User Profile.aspx");
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            uobj.User_id = Convert.ToInt32(Session["user_id"]);
            uobj.Ufname = txtfname.Text;
            uobj.Umname = txtmname.Text;
            uobj.Ulname = txtlname.Text;
           
            uobj.Uhousename = txthousename.Text;
            uobj.Uwardno = txtwardno.Text;
            uobj.Uplace = txtplace.Text;
      
            uobj.Uphone_no = txtphoneno.Text;
           // uobj.UserEmail = txtemail.Text;
          
            uobj.update();
            lblmsg.Visible = true;
            lblmsg.Text = "data updated";
        }

        
    }
}