﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;



namespace CableManPro1.Registration
{
 
    public partial class Login : System.Web.UI.Page
    {

        CableClass cobj = new CableClass();

        

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnsubmit_Click1(object sender, EventArgs e)
        {
            
        
          
            
            DataTable dtReg = new DataTable();
            cobj.Uemail = txtusemailid.Text;
            cobj.Upassword = txtpswd.Text;
            dtReg=cobj.ExecuteSelectQueries();
            if(txtusemailid.Text=="admin@gmail.com" && txtpswd.Text=="admin")
            {
                if (dtReg.Rows.Count > 0)
                {
                    lblmsg.Text = " Sucess.";

                }
                else
                {
                    lblmsg.Text = " Incorrect Try again..!!";
                }

                Response.Redirect("~/Admin Module/AdminHome.aspx");
           
            }

            
              
            if (dtReg.Rows.Count > 0)
            {
             lblmsg.Text = " Sucess.";
                   
            }
           else
           {
               lblmsg.Text = " Incorrect Try again..!!";
           }

            Response.Redirect("~/User/UserHome.aspx");


          






        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
          Response.Redirect  ("~/Default.aspx");
        }

      
       
    }
}