﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Class
{
    public class CableClass
    {


        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        private string ufname;

        public string Ufname
        {
            get { return ufname; }
            set { ufname = value; }
        }


        private string umname;

        public string Umname
        {
            get { return umname; }
            set { umname = value; }
        }


        private string ulname;

        public string Ulname
        {
            get { return ulname; }
            set { ulname = value; }
        }


        private string ugender;

        public string Ugender
        {
            get { return ugender; }
            set { ugender = value; }
        }


        private string uhousename;

        public string Uhousename
        {
            get { return uhousename; }
            set { uhousename = value; }
        }

        private Int16 uwardnum;

        public Int16 Uwardnum
        {
            get { return uwardnum; }
            set { uwardnum = value; }
        }


        private string uplace;

        public string Uplace
        {
            get { return uplace; }
            set { uplace = value; }
        }



        private long umob;

        public long Umob
        {
            get { return umob; }
            set { umob = value; }
        }




        private string uemail;

        public string Uemail
        {
            get { return uemail; }
            set { uemail = value; }
        }


        private string upassword;

        public string Upassword
        {
            get { return upassword; }
            set { upassword = value; }
        }


        public void UserRegistration()
        {

            OpenConection();
            SqlCommand command = new SqlCommand("Select max(user_id) from User_Register ", con);
            int user_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                user_id = (int)cMax;
                user_id++;
            }
            else
            {
                user_id = 1;
            }

            string qry = "insert into user_register values(@fname,@mname,@lname,@gender,@housename,@wardnum,@place,@mob,@email,@password)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@fname",ufname);
            cmd.Parameters.AddWithValue("@mname", umname);
            cmd.Parameters.AddWithValue("@lname", ulname);
            cmd.Parameters.AddWithValue("@gender",ugender);
            cmd.Parameters.AddWithValue("@housename", uhousename);
            cmd.Parameters.AddWithValue("@wardnum", uwardnum);
            cmd.Parameters.AddWithValue("@place", uplace);
            cmd.Parameters.AddWithValue("@mob", umob);
            cmd.Parameters.AddWithValue("@email", uemail);
            cmd.Parameters.AddWithValue("@password", upassword);
            cmd.ExecuteNonQuery();
           // ExecuteQueries(qry);
        }
/// <summary>
/// /--------employee registration----
/// </summary>
        private string efname;
  
        public string Efname
        {
            get { return efname; }
            set { efname = value; }
        }


        private string emname;

        public string Emname
        {
            get { return emname; }
            set { emname = value; }
        }

        private string elname;

        public string Elname
        {
            get { return elname; }
            set { elname = value; }
        }

        private string egender;

        public string Egender
        {
            get { return egender; }
            set { egender = value; }
        }


        private DateTime edob;

        public DateTime Edob
        {
            get { return edob; }
            set { edob = value; }
        }


        private DateTime edoj;

        public DateTime Edoj
        {
            get { return edoj; }
            set { edoj = value; }
        }

        private string ehousename;

        public string Ehousename
        {
            get { return ehousename; }
            set { ehousename = value; }
        }


        private string eplace;

        public string Eplace
        {
            get { return eplace; }
            set { eplace = value; }
        }


        private string edistrict;

        public string Edistrict
        {
            get { return edistrict; }
            set { edistrict = value; }
        }


        private string epincode;

        public string Epincode
        {
            get { return epincode; }
            set { epincode = value; }
        }


        private string emob;

        public string Emob
        {
            get { return emob; }
            set { emob = value; }
        }


        private string equalification;

        public string Equalification
        {
            get { return equalification; }
            set { equalification = value; }
        }



        private string edesignation;

        public string Edesignation
        {
            get { return edesignation; }
            set { edesignation = value; }
        }


        private string eemail;

        public string Eemail
        {
            get { return eemail; }
            set { eemail = value; }
        }



        private string epassword;

        public string Epassword
        {
            get { return epassword; }
            set { epassword = value; }
        }




        public void EmployeRegistration()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(emp_id) from emp_Register ", con);

            int emp_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                emp_id = (int)cMax;
                emp_id++;
            }
            else
            {
                emp_id = 1;
            }
            string qry = "insert into emp_register ( emp_fname,emp_mname,emp_lname,emp_gender, "
                             +"emp_dob,emp_doj,emp_housename,emp_place,emp_district,emp_pincode,emp_mob,"
                             +"emp_qualification,emp_designation,emp_emailid,emp_password) values(@efname,"
                             +"@emname,@elname,@egender,@edob,@edoj,@ehousename,@eplace,@edistrict,@epincode,"
                             +"@emob,@equalification,@edesignation,@eemail,@epassword)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@efname",efname );
            cmd.Parameters.AddWithValue("@emname", emname);
            cmd.Parameters.AddWithValue("@elname", elname);
            cmd.Parameters.AddWithValue("@egender", egender);
            cmd.Parameters.AddWithValue("@edob", edob);
            cmd.Parameters.AddWithValue("@edoj", edoj);
            cmd.Parameters.AddWithValue("@ehousename", ehousename);
            cmd.Parameters.AddWithValue("@eplace", eplace);
            cmd.Parameters.AddWithValue("@edistrict", edistrict);
            cmd.Parameters.AddWithValue("@epincode", epincode);
            cmd.Parameters.AddWithValue("@equalification", equalification);
            cmd.Parameters.AddWithValue("@edesignation", edesignation);
            cmd.Parameters.AddWithValue("@emob", emob);
            cmd.Parameters.AddWithValue("@eemail", eemail);
            cmd.Parameters.AddWithValue("@epassword", epassword);
            cmd.ExecuteNonQuery();

        
        }

       // ---login page---



        private string emailid;

        public string Emailid
        {
            get { return emailid; }
            set { emailid = value; }
        }


        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public DataTable ExecuteSelectQueries()
        {


            
            OpenConection();
            string qry = "select * from  user_register  where user_emailid=@emailid  and user_password= @password ";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@emailid", uemail);
            cmd.Parameters.AddWithValue("@password", upassword);
            
            cmd.ExecuteNonQuery();
            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
          return dtReg;
        }

        
    }
}