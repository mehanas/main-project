﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;


namespace CableManPro1.User
{
    public partial class ViewReplyComplaint : System.Web.UI.Page
    {
        ComplaintClass combj = new ComplaintClass();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (HttpContext.Current.Session["user_id"] == null)
            {
                Response.Redirect("~/User/User Profile.aspx");
            }
            else if (!IsPostBack)
            {
                DataTable dt = new DataTable();
                combj.User_id = Convert.ToInt32(Session["user_id"]);
               dt=combj.viewcomplaintrply();
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }

        }

    }
}