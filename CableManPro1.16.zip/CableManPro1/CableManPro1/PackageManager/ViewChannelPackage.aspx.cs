﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.PackageManager
{
    public partial class ViewChannelPackage : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {
           gv_view_channels.Visible = false;

            if (!IsPostBack)
            {
               
                Load_Package_Data();
                selectchannel();
                
            }
        }
        
        private void Load_Package_Data()
        {
            DataTable dtpackage = new DataTable();
            dtpackage = pobj.show_package_data();

            if (dtpackage.Rows.Count > 0)
            {
                
                gv_view_packages.DataSource = dtpackage;
                gv_view_packages.DataBind();
            }
        }

        private void selectchannel()
        {

            DataTable dtchannel = new DataTable();
            pobj.PackageId =Convert.ToInt32(ViewState["PackageId"]);
            dtchannel = pobj.selectchannel();

            if (dtchannel.Rows.Count > 0)
            {

                gv_view_channels.DataSource = dtchannel;
                gv_view_channels.DataBind();
                gv_view_channels.Visible = true;
            }

        }

        protected void gv_view_packages_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow clickedRow = gv_view_packages.Rows[index];          

            HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnPackageId");
          
            ViewState["PackageId"] = gv_view_packages.Rows[index].Cells[0].Text; 
            Label2.Text = "Package : " + clickedRow.Cells[2].Text;
            selectchannel();
           
            
        }

      
        

       
    }
}