﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Registration
{
    public partial class UserRegistration : System.Web.UI.Page
    {


        CableClass cobj = new CableClass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnregister_Click1(object sender, EventArgs e)
        {
            if (rdbufemale.Checked)
            {
                cobj.Ugender = rdbufemale.Text;
            }
            else
            {
                cobj.Ugender = rdbumale.Text;
            }

            cobj.Ufname = txtufname.Text;
            cobj.Umname = txtumname.Text;
            cobj.Ulname = txtulname.Text;
            cobj.Uhousename = txtuhousename.Text;
            cobj.Uplace = txtuplace.Text;
            cobj.Umob = Convert.ToInt64(txtuphn.Text);
            cobj.Uemail = txtuemailid.Text;
            cobj.Upassword = txtupassword.Text;

            cobj.UserRegistration();

            txtuemailid.Text = "";
            txtufname.Text = "";
            txtumname.Text = "";
            txtulname.Text = "";
            txtuhousename.Text = "";
            txtuplace.Text = "";
            txtuphn.Text = "";
            txtupassword.Text = "";

            lblmessage.Text = " Registration Sucessfully"; 


        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            
        }
        
    }
}