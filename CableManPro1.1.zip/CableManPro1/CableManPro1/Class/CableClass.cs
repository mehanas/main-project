﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Class
{
    public class CableClass
    {


        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        private string ufname;

        public string Ufname
        {
            get { return ufname; }
            set { ufname = value; }
        }


        private string umname;

        public string Umname
        {
            get { return umname; }
            set { umname = value; }
        }


        private string ulname;

        public string Ulname
        {
            get { return ulname; }
            set { ulname = value; }
        }


        private string ugender;

        public string Ugender
        {
            get { return ugender; }
            set { ugender = value; }
        }


        private string uhousename;

        public string Uhousename
        {
            get { return uhousename; }
            set { uhousename = value; }
        }


        private string uplace;

        public string Uplace
        {
            get { return uplace; }
            set { uplace = value; }
        }



        private long umob;

        public long Umob
        {
            get { return umob; }
            set { umob = value; }
        }




        private string uemail;

        public string Uemail
        {
            get { return uemail; }
            set { uemail = value; }
        }


        private string upassword;

        public string Upassword
        {
            get { return upassword; }
            set { upassword = value; }
        }


        public void UserRegistration()
        {
            OpenConection();
            string qry = "insert into user_register values('" + ufname + "','" + umname + "','" + ulname + "','" + ugender + "','" + uhousename + "','" + uplace + "'," + umob + ",'" + uemail + "','" + upassword + "')";
            ExecuteQueries(qry);
        }

    }
}