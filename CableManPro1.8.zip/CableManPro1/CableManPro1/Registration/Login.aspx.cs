﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;



namespace CableManPro1.Registration
{
 
    public partial class Login : System.Web.UI.Page
    {

        CableClass cobj = new CableClass();

        

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnsubmit_Click1(object sender, EventArgs e)
        {

            DataTable dtUserReg = new DataTable();
            DataTable dtEmpReg = new DataTable();

            cobj.Uemail = txtusemailid.Text;
            cobj.Upassword = txtpswd.Text;
            dtUserReg = cobj.ExecuteSelectQueries();
            dtEmpReg = cobj.CheckEmployeeLogin();

            if (txtusemailid.Text == "admin@gmail.com" && txtpswd.Text == "admin")
            {
                Session["admin"] = txtusemailid.Text;
                Response.Redirect("~/Admin Module/AdminHome.aspx");

            }
            else if (dtUserReg.Rows.Count > 0)
            {
                Session["user"] = txtusemailid.Text;
                Session["user_id"] =Convert.ToString(dtUserReg.Rows[0]["user_id"]);
                Response.Redirect("~/User/UserHome.aspx");

            }
            else if (dtEmpReg.Rows.Count > 0)
            {
                cobj.Edesignation = dtEmpReg.Rows[0]["emp_designation"].ToString();
                if (cobj.Edesignation == "complaint manager")
                {
                    Session["employe"] = txtusemailid.Text;
                    Response.Redirect("~/CoplaintManager/ComplaintHome.aspx");
                }

                else if (cobj.Edesignation == "package manager")
                {
                    Session["packageemploy"] = txtusemailid.Text;
                    Response.Redirect("~/PackageManager/PackageHome.aspx");
                }

            }
            else
            {

                lblmsg.Text = "invalid userid and password";
            }
        } 

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Registration/Login.aspx");
        }

      
       
    }
}