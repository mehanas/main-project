﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.PackageManager
{
    public partial class ViewChannelPackage : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               // LoadData();
                Load_Package_Data();
            }
        }
        //private void LoadData()
        //{
        //    DataTable dtchannel = new DataTable();
        //    dtchannel = pobj.show_channel_data();

        //    if (dtchannel.Rows.Count > 0)
        //    {
        //        gv_view_channels.DataSource = dtchannel;
        //        gv_view_channels.DataBind();
        //    }
        //}
        private void Load_Package_Data()
        {
            DataTable dtpackage = new DataTable();
            dtpackage = pobj.show_package_data();

            if (dtpackage.Rows.Count > 0)
            {
                
                gv_view_packages.DataSource = dtpackage;
                gv_view_packages.DataBind();
            }


        }
    }
}