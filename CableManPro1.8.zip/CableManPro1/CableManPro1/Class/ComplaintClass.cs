﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Class
{
    public class ComplaintClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        private string complaint;

        public string Complaint
        {
            get { return complaint; }
            set { complaint = value; }
        }
       
        private int user_id;

        public int User_id
        {
            get { return user_id; }
            set { user_id = value; }
        }

       

        public int insertcomplaint()
        {

            OpenConection();
            SqlCommand command = new SqlCommand("select max(complaint_id) from complaint",con);
            int complaint_id;
          //  string status;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                complaint_id = (int)cMax;
                complaint_id++;
            }
            else
            {
                complaint_id = 1;
            }
           //status = "not read";
           string qry = "insert into complaint ([complaint_id],[user_id],[complaint_date],[complaint_details] " +
                        ",[complaint_status]) values('" + complaint_id + "',@user_id,GETDATE(),@complaint_details,@status )";
           
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@complaint_details",complaint );
            cmd.Parameters.AddWithValue("@user_id", user_id);
            
            cmd.ExecuteNonQuery();

            CloseConnection();
            return complaint_id;
        
        }
        public DataTable showdata()
        {
            OpenConection();
            string qry2 = " select com.complaint_id,com.complaint_date,com.complaint_details,com.complaint_status,usr.user_fname  from " + 
                         " complaint com left outer join user_register usr on com.user_id = usr.user_id "+
                         "  and com.complaint_status !='Completed' ";
          
            SqlCommand cmd = new SqlCommand(qry2, con);
          
         
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;

        }
        private string comp_rply;

        public string Comp_rply
        {
            get { return comp_rply; }
            set { comp_rply = value; }
        }
        private int complaint_id;

        public int Complaint_id
        {
            get { return complaint_id; }
            set { complaint_id = value; }
        }
        public void sendcomplaint()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max( reply_id) from complaint_reply ", con);
            int reply_id;
           
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                reply_id = (int)cMax;
                reply_id++;
            }
            else
            {
                reply_id = 1;
            }
           
            string qry = "insert into complaint_reply ([reply_id],[comp_reply],[reply_date],[complaint_id]) values ('" + reply_id + "',@comp_rply,GETDATE(),@complaint_id)";
            
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@comp_rply", comp_rply);
            cmd.Parameters.AddWithValue("@complaint_id",complaint_id);
            cmd.ExecuteNonQuery();    
        
        }
        private string status;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }


        public void sendstatus()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max(status_id) from complaint_status ", con);
            int status_id;

            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                status_id = (int)cMax;
                status_id++;
            }
            else
            {
                status_id = 1;
            }
            string qry = "insert into complaint_status values ('" + status_id + "',@status,GETDATE(),@comp_id)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@comp_id", complaint_id);
            cmd.ExecuteNonQuery();

        }
        public DataTable currentstatus()
        {
            OpenConection();
            string qry = " select * from dbo.complaint_status where complaint_id =@comp_id order by status_date desc";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@comp_id", complaint_id);
            cmd.ExecuteNonQuery();

            DataTable dtstatus = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtstatus);
            CloseConnection();
            return dtstatus;


        }


    }
}