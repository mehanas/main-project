﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.Admin_Module
{
    public partial class ViewEmployes : System.Web.UI.Page
    {
        AdminClass aobj = new AdminClass();


        protected void Page_Load(object sender, EventArgs e)
        {


        }

    }
}