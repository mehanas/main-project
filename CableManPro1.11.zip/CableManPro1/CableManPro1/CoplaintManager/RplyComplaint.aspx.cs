﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.CoplaintManager
{
    public partial class RplyComplaint : System.Web.UI.Page
    {
        ComplaintClass comobj = new ComplaintClass();

        protected void Page_Load(object sender, EventArgs e)
        {

            txtrply.Visible = false;
            rbtnStatus.Visible = false;
            if (HttpContext.Current.Session["employe"] == null)
            {
                Response.Redirect("~/User/UserHome.aspx");
                Response.Redirect("~/CoplaintManager/ComplaintHome.aspx");
            }
            else if (!IsPostBack)
            {
                DataTable dt = new DataTable();

                dt = comobj.showdata();
                if (dt.Rows.Count > 0)
                {
                    gvcomplaint.DataSource = dt;
                    gvcomplaint.DataBind();
                }
            }

        }

        protected void gvcomplaint_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow clickedRow = gvcomplaint.Rows[index];
            HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnComId");
            Session["complaint_id"] = hidden.Value;
            if (e.CommandName == "Reply")
            {
                
                
                txtrply.Visible = true;
                ViewState["action"] = "Reply";
            }
            else if (e.CommandName == "Status")
            {
                DataTable dtstatus = new DataTable();
                comobj.Complaint_id = Convert.ToInt32(Session["complaint_id"]);
                dtstatus = comobj.currentstatus();
                if (dtstatus.Rows.Count > 0)
                {
                    rbtnStatus.SelectedValue = Convert.ToString(dtstatus.Rows[0]["status"]);
                }

                rbtnStatus.Visible = true;
                ViewState["action"] = "Status";
            }
        }

        protected void btnsend_Click(object sender, EventArgs e)
        {
           

            comobj.Complaint_id = Convert.ToInt32(Session["complaint_id"]);

            if (Convert.ToString(ViewState["action"]) == "Reply")
            {
                comobj.Comp_rply = txtrply.Text;
                comobj.sendcomplaint();
                lblmsg.Text = "send message";
                comobj.Comp_rply = "";

            }
            else if (Convert.ToString(ViewState["action"]) == "Status")
            {
                comobj.Status = rbtnStatus.SelectedValue;
                comobj.sendstatus();
                lblmsg.Text = "send status";
            }
         
           

           
        
            

        }


    }
}