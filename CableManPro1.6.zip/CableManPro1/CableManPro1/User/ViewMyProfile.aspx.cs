﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class ViewMyProfile : System.Web.UI.Page
    {

       UserClass uobj=new UserClass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["user"] == null)
            {
                Response.Redirect("~/User/UserHome.aspx");
            }
            else if (!IsPostBack)
            {
                 DataTable dt = new DataTable();
                 uobj.UserEmail =Convert.ToString(Session["user"]);
                 dt = uobj.showdata();
                 if (dt.Rows.Count > 0)
                 {
                     dvuser.DataSource = dt;
                     dvuser.DataBind();
                 }
            }
        }
      


        protected void dvuser_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
        {
           
              
        }
       
    }
}