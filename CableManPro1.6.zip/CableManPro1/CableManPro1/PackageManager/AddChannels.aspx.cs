﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.PackageManager
{
    public partial class AddChannels : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            pobj.Channel = txtchannel.Text;
            if (Convert.ToInt32(ddl_language.SelectedValue) != 0)
            pobj.Language = ddl_language.SelectedItem.Text;
            pobj.Channel_rate = Convert.ToInt32(txtch_rate.Text);

            pobj.insertchannel();

            lblmsg.Text = "Channel Inserted";

        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/PackageManager/AddChannels.aspx");
        }
    }
}