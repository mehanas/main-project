﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CableManPro1.PackageManager
{
    public partial class Package : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = "welcome " + " " + Session["packageemploy"].ToString();
        }
    }
}