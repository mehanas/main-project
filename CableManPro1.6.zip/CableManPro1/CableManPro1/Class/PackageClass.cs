﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace CableManPro1.Class
{
    public class PackageClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// -------------------insert channel----------------
        /// </summary>


        private string channel;

        public string Channel
        {
            get { return channel; }
            set { channel = value; }
        }
        private string language;

        public string Language
        {
            get { return language; }
            set { language = value; }
        }
        private Int32 channel_rate;

        public Int32 Channel_rate
        {
            get { return channel_rate; }
            set { channel_rate = value; }
        }


        public void insertchannel()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max (channel_id) from channel_details  ", con);
            int channel_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                channel_id = (int)cMax;
                channel_id++;
            }
            else
            {
                channel_id = 1;
            }
            string qry = "insert into channel_details values('" + channel_id + "',@channel,@language,@channel_rate)";
            SqlCommand cmd = new SqlCommand(qry, con);
            //cmd.Parameters.AddWithValue("@channel_id", channel_id);
            cmd.Parameters.AddWithValue("@channel", channel);
            cmd.Parameters.AddWithValue("@language", language);
            cmd.Parameters.AddWithValue("@channel_rate", channel_rate);
            cmd.ExecuteNonQuery();

        }
        
        ///---------------insert package---------------------

        private string package_name;

        public string Package_name
        {
            get { return package_name; }
            set { package_name = value; }
        }

        private Int32 package_rate;

        public Int32 Package_rate
        {
            get { return package_rate; }
            set { package_rate = value; }
        }

        private int channel_id;

        public int Channel_id
        {
            get { return channel_id; }
            set { channel_id = value; }
        }

        private string no_of_channels;

        public string No_of_channels
        {
            get { return no_of_channels; }
            set { no_of_channels = value; }
        }

        public void insertpackage()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max (package_id) from package_details  ", con);
            int package_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                package_id = (int)cMax;
                package_id++;
            }
            else
            {
                package_id = 1;
            }
            string qry = "insert into package_details values('" + package_id + "',@package_name,@package_rate,@no_of_channels,@channel_id)";
            SqlCommand cmd = new SqlCommand(qry, con);
           
            cmd.Parameters.AddWithValue("@package_name", package_name);
            cmd.Parameters.AddWithValue("@package_rate", package_rate);
             cmd.Parameters.AddWithValue("@no_of_channels",no_of_channels);
            cmd.Parameters.AddWithValue("@channel_id", channel_id);
            cmd.ExecuteNonQuery();
        }
    }
}
