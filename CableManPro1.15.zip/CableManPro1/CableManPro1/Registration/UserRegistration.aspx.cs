﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace CableManPro1.Registration
{
    public partial class UserRegistration : System.Web.UI.Page
    {

        
        CableClass cobj = new CableClass();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmessage.Visible = false;
        }

        protected void Btnregister_Click1(object sender, EventArgs e)
        {
            cobj.Uemail = txtuemailid.Text;
            string utyp = "";
            utyp = cobj.userdata();
            if (utyp != null)
            {

                Response.Write("<script>alert('username already exists')</script>");
            }
            else
            {

                if (rdbufemale.Checked)
                {
                    cobj.Ugender = rdbufemale.Text;
                }
                else
                {
                    cobj.Ugender = rdbumale.Text;
                }

                cobj.Ufname = txtufname.Text;
                cobj.Umname = txtumname.Text;
                cobj.Ulname = txtulname.Text;
                cobj.Uhousename = txtuhousename.Text;
                cobj.Uwardnum = Convert.ToInt16(txtwardnum.Text);
                cobj.Uplace = txtuplace.Text;
                cobj.Umob = Convert.ToInt64(txtuphn.Text);
                cobj.Uemail = txtuemailid.Text;
                cobj.Upassword = txtupassword.Text;

                cobj.UserRegistration();
                lblmessage.Visible = true;

                txtuemailid.Text = "";
                txtufname.Text = "";
                txtumname.Text = "";
                txtulname.Text = "";
                txtuhousename.Text = "";
                txtwardnum.Text = "";
                txtuplace.Text = "";
                txtuphn.Text = "";
                txtupassword.Text = "";
                Response.Write("<script>alert('Registration successfully')</script>");

                string uname = cobj.Uemail;
                string password = cobj.Upassword;


                string msg = "Thanks for choosing this website.You are succesfully Registered!!!Login to complete your profile.Your WeShare@SSPA login credentials are the following:UserName='" + uname + "' and Password='" + password + "'";// To Complete the Registeration,login and complete your profile";

                string mFrom = "grouptravelix2018@gmail.com";
                string mPwd = "travelix1234";
                string mTo = uname;
                try
                {
                    MailAddress mailto = new MailAddress(mTo);
                    MailAddress mailfrom = new MailAddress("grouptravelix2018@gmail.com");
                    MailMessage message = new MailMessage(mailfrom, mailto);

                    message.Subject = "weShare@sspa user Approval";
                    message.Body = msg;
                    message.IsBodyHtml = true;
                  
                    SmtpClient smtps = new SmtpClient("smtp.gmail.com", 587);
                    smtps.UseDefaultCredentials = false;
                    smtps.Credentials = new NetworkCredential(mFrom, mPwd);
                    smtps.EnableSsl = true;
                    smtps.Send(message);
                  
                }
                catch (Exception exp)
                {

                    Response.Write("<script>alert('No Internet Connection To send Confirmation Email')</script>" + exp);

                }

            }
            
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Registration/UserRegistration.aspx");
        }
        
    }
}