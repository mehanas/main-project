﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.User
{
    public partial class ConnectionRequest : System.Web.UI.Page
    {
        AdminClass aobj = new AdminClass();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
             lblmsg.Visible = true;
             aobj.User_id = Convert.ToInt32(Session["user_id"]);  
             aobj.Con_status = "0";

             

             if (chk_internet.Checked== true)
             {
                 aobj.Net_status = "1";
             }
             else 
             {

                 aobj.Net_status = "0";
             }

             aobj.SendRequest();
             lblmsg.Text = "Request send";
             
        }
    }
}