﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace CableManPro1.Class
{
    public class UserClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        private string userEmail = string.Empty;

        public string UserEmail
        {
            get { return userEmail; }
            set { userEmail = value; }
        }

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public DataTable showdata()
        {
            OpenConection();
            string qry2 = "select * from User_Register  where user_emailid=@emailid";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@emailid", userEmail);
         
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;

        }

        //------------------edit profile---------------------------------

        private int user_id;

        public int User_id
        {
            get { return user_id; }
            set { user_id = value; }
        }
        private string ufname;

        public string Ufname
        {
            get { return ufname; }
            set { ufname = value; }
        }

        private string umname;

        public string Umname
        {
            get { return umname; }
            set { umname = value; }
        }

        private string ulname;

        public string Ulname
        {
            get { return ulname; }
            set { ulname = value; }
        }
        private string ugender;

        public string Ugender
        {
            get { return ugender; }
            set { ugender = value; }
        }
        private string uhousename;

        public string Uhousename
        {
            get { return uhousename; }
            set { uhousename = value; }
        }
        private string uwardno;

        public string Uwardno
        {
            get { return uwardno; }
            set { uwardno = value; }
        }

        private string uplace;

        public string Uplace
        {
            get { return uplace; }
            set { uplace = value; }
        }

        private string uphone_no;

        public string Uphone_no
        {
            get { return uphone_no; }
            set { uphone_no = value; }
        }

        private string uemailid;

        public string Uemailid
        {
            get { return uemailid; }
            set { uemailid = value; }
        }

        private string upswd;

        public string Upswd
        {
            get { return upswd; }
            set { upswd = value; }
        }

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();

            String qry = "select * from user_register ";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dtReg1 = new DataTable();
            da.Fill(dtReg);

            return dtReg;

        }

        public DataTable disply()
        {
            DataTable dtReg = new DataTable();
            OpenConection();

            String qry = "select * from user_register where user_id=@user_id";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@user_id", user_id);
            cmd.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);

            CloseConnection();
            return dtReg;
        }

        public void update()
        {

            OpenConection();


            String qry1 = "update user_register set user_fname=@ufname,user_mname=@umname,user_lname=@ulname,user_housename=@uhousename,user_wardno=@uwardno,user_place=@uplace,user_mob=@uphone_no,user_password=@upaswd where user_id=@user_id";
            SqlCommand cmd1 = new SqlCommand(qry1, con);

            cmd1.Parameters.AddWithValue("@user_id", user_id);
            cmd1.Parameters.AddWithValue("@ufname", ufname);
            cmd1.Parameters.AddWithValue("@umname", umname);
            cmd1.Parameters.AddWithValue("@ulname", ulname);

          
            cmd1.Parameters.AddWithValue("@uhousename", uhousename);
            cmd1.Parameters.AddWithValue("@uwardno", uwardno);

            cmd1.Parameters.AddWithValue("@uplace", uplace);
            cmd1.Parameters.AddWithValue("@uphone_no", uphone_no);

            
            cmd1.ExecuteNonQuery();
        }
        public void changepswd()
        {
            OpenConection();
            String qry1 = "update user_register set user_password=@upaswd where user_id=@user_id";
            SqlCommand cmd1 = new SqlCommand(qry1, con);
            cmd1.Parameters.AddWithValue("@user_id", user_id);
            cmd1.Parameters.AddWithValue("@upaswd", upswd);
            cmd1.ExecuteNonQuery();
        
        }



    }
}