﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;
namespace CableManPro1.CoplaintManager
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        ComplaintClass cobj = new ComplaintClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["employe"] == null)
            {
               
                Response.Redirect("~/CoplaintManager/ComplaintHome.aspx");
            }
            if (!IsPostBack)
            {
                string Uid = Session["employe"].ToString();

                Loaddata();
            }
        }

        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            cobj.E_email = Session["employe"].ToString();
            dtReg = cobj.disply();
            if (dtReg.Rows.Count > 0)
            {
                txtmail_id.Text = Convert.ToString(dtReg.Rows[0]["emp_emailid"]);
                txt_pswd.Text = Convert.ToString(dtReg.Rows[0]["emp_password"]);
            }
        }

        protected void btn_edit_Click(object sender, EventArgs e)
        {

            txt_pswd.Enabled = true;
            btn_edit.Visible = false;
            btn_save.Visible = true;

        }

        protected void btn_save_Click(object sender, EventArgs e)
        {

            cobj.E_email = Session["employe"].ToString();
            // uobj.UserEmail = txtmail_id.Text;
            cobj.Emp_password = txt_pswd.Text;
            cobj.changepswd();

            Response.Write("<script>alert('updation successfully')</script>");
            txt_pswd.Enabled = false;
        }
    }
}