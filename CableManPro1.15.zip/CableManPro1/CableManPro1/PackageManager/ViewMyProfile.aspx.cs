﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;

namespace CableManPro1.PackageManager
{
    public partial class ViewMyProfile : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();


        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;

            if (HttpContext.Current.Session["packageemploy"] == null)
            {
                Response.Redirect("~/PackageManager/PackageHome.aspx");
            }
         
            if (!IsPostBack)
            {
                string Uid = Session["packageemploy"].ToString();
              
                Loaddata();
            }

        }
        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            pobj.E_email = Session["packageemploy"].ToString();
            dtReg = pobj.disply();
            if (dtReg.Rows.Count > 0)
            {
               
                    if (dtReg.Rows[0]["emp_gender"].ToString() == "male")
                    {
                        rdbmale.Checked = true;

                    }
                    else
                    {
                        rdbfemale.Checked = true;
                    }

                txtfname.Text = Convert.ToString(dtReg.Rows[0]["emp_fname"]);
                txtmname.Text = Convert.ToString(dtReg.Rows[0]["emp_mname"]);
                txtlname.Text = Convert.ToString(dtReg.Rows[0]["emp_lname"]);
                txtdob.Text=Convert.ToString(dtReg.Rows[0]["emp_dob"]);
                txtdoj.Text = Convert.ToString(dtReg.Rows[0]["emp_doj"]);
                txthousename.Text = Convert.ToString(dtReg.Rows[0]["emp_housename"]);
                txtplace.Text = Convert.ToString(dtReg.Rows[0]["emp_place"]);
                txtdistrict.Text = Convert.ToString(dtReg.Rows[0]["emp_district"]);
                txtpincode.Text=Convert.ToString(dtReg.Rows[0]["emp_pincode"]);
                txtmob.Text = Convert.ToString(dtReg.Rows[0]["emp_mob"]);
                txtqualification.Text = Convert.ToString(dtReg.Rows[0]["emp_qualification"]);
                txtdesignation.Text = Convert.ToString(dtReg.Rows[0]["emp_designation"]);
                txtemail.Text = Convert.ToString(dtReg.Rows[0]["emp_emailid"]);
               
               
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            pobj.E_email = Session["packageemploy"].ToString();
            pobj.E_fname = txtfname.Text;
            pobj.E_mname = txtmname.Text;
            pobj.E_lname = txtlname.Text;
            pobj.Dob = txtdob.Text;
            pobj.Doj = txtdoj.Text;
            pobj.E_housename = txthousename.Text;
            pobj.E_place = txtplace.Text;
            pobj.E_district = txtdistrict.Text;
            pobj.E_pincode = txtpincode.Text;
            pobj.Mob = txtmob.Text;
            pobj.E_qualification = txtqualification.Text;
            pobj.E_designation = txtdesignation.Text;
            pobj.update();
            lblmsg.Visible = true;
            lblmsg.Text = "data updated";
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            txtfname.Enabled = true;
            txtmname.Enabled = true;
            txtlname.Enabled = true;
           // txtdoj.Enabled = true;
            txtdob.Enabled = true;
            txtdistrict.Enabled = true;
            txthousename.Enabled = true;
            txtplace.Enabled = true;
            txtpincode.Enabled = true;
            txtmob.Enabled = true;
            txtqualification.Enabled = true;
           // txtemail.Enabled = true;
            btnupdate.Visible = true;
            btnedit.Visible = false;
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/PackageManager/ViewMyProfile.aspx");
        }
        }


}
