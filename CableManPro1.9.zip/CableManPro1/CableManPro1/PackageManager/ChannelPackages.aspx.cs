﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CableManPro1.Class;
using System.Data;
using System.Data.SqlClient;


namespace CableManPro1.PackageManager
{
    public partial class ChannelPackages : System.Web.UI.Page
    {
        PackageClass pobj = new PackageClass();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadData();
                Load_Package_Data();
            }
        }
        private void LoadData()
        {
            DataTable dtchannel = new DataTable();
            dtchannel = pobj.show_channel_data();

            if (dtchannel.Rows.Count > 0)
            {
               gvch_select.DataSource = dtchannel;
                gvch_select.DataBind();
            }
        }
        private void Load_Package_Data()
        {
            DataTable dtpackage = new DataTable();
            dtpackage = pobj.show_package_data();

            if (dtpackage.Rows.Count > 0)
            {
                gvPackage.DataSource = dtpackage;
                gvPackage.DataBind();
            }


        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            pobj.PackageId =Convert.ToInt32(ViewState["PackageId"]);
          
            foreach (GridViewRow rw in gvch_select.Rows)
            {
                CheckBox chkBx = (CheckBox)rw.FindControl("cb_chselect");
               if (chkBx != null && chkBx.Checked)
               {
                   pobj.ChannelId =Convert.ToInt32(((HiddenField)rw.FindControl("hdnChannelId")).Value);
                   pobj.InsertChannelPackage();
               }
            }
        }

      
        protected void gvPackage_RowCommand(object sender, GridViewCommandEventArgs e)
        {
              int index = Convert.ToInt32(e.CommandArgument);
              GridViewRow clickedRow = gvPackage.Rows[index];
              HiddenField hidden = (HiddenField)clickedRow.Cells[2].FindControl("hdnPackageId");
              ViewState["PackageId"] = hidden.Value;
              lblPackage.Text = "Selected Package : " + clickedRow.Cells[0].Text;
              gvch_select.Visible = true;
        }
        
    }
}