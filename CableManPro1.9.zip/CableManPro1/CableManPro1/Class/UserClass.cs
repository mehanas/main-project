﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace CableManPro1.Class
{
    public class UserClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        private string userEmail = string.Empty;

        public string UserEmail
        {
            get { return userEmail; }
            set { userEmail = value; }
        }

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public DataTable showdata()
        {
            OpenConection();
            string qry2 = "select * from User_Register  where user_emailid=@emailid";
            SqlCommand cmd = new SqlCommand(qry2, con);
            cmd.Parameters.AddWithValue("@emailid", userEmail);
         
            cmd.ExecuteNonQuery();

            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;


          
        
        }
    }
}